package virtue.sinssmp;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1937;
import net.minecraft.class_2378;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8113.class_8122;
import net.minecraft.class_9290;
import net.minecraft.class_9304;
import net.minecraft.class_9381;
import net.minecraft.class_9886;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.HashSet;
import java.util.Set;

public class SinsSmp implements ModInitializer {
	public static final String MOD_ID = "sinssmp";
	private static final Map<class_1792, Object[]> ENCHANTMENTS_BY_ITEM = new HashMap<>();
	public static final class_1792 ENDLESS_MAW = registerSword("endless_maw", new String[]{
			"An abyssal edge that hungers for every last crumb of life.",
			"Passive â€” While held, food restores 40% more saturation.",
			"Endless Hunger â€” For 45 seconds, drain 10% saturation from non-allied players within 7 blocks every 10 seconds.",
			"Cooldown: 45 seconds. Right-click to activate."
	}, "sharpness", 5, "looting", 3, "fire_aspect", 2, "sweeping_edge", 3, "knockback", 2, "unbreaking", 3, "mending", 1);
	public static final class_1792 HOARD_EATER = registerSword("hoard_eater", new String[]{
			"A gilded blade that turns every feast into a fortune.",
			"Passive â€” While held, golden apples have a 20% chance to be rejected.",
			"Feast of Gold â€” For 30 seconds, your next golden apple grants 10% longer Regeneration.",
			"Cooldown: 30 seconds. Eat the apple within 30 seconds."
	}, "sharpness", 5, "looting", 3, "fire_aspect", 2, "sweeping_edge", 3, "knockback", 2, "unbreaking", 3, "mending", 1);
	public static final class_1792 SIRENS_KISS = registerSword("sirens_kiss", new String[]{
			"A rose-bright blade carrying a treacherous song.",
			"Passive â€” Hits have a 5% chance to inflict Weakness I for 20 seconds.",
			"Lust's Lament: Fire four wide heart beams; the ground ruptures beneath you as wither, poison, hunger, or damage follows each hit.",
			"Cooldown: 60 seconds. Right-click to activate."
	}, "sharpness", 5, "looting", 3, "fire_aspect", 2, "sweeping_edge", 3, "knockback", 2, "unbreaking", 3, "mending", 1);
	public static final class_1792 WRATH_SWORD = registerSword("wrath_of_the_silent_king", new String[]{
			"Forged for a king whose rage outlived his name.",
			"Passive â€” Strength II while held in your main hand.",
			"Wrath Flame: Summon a spiraling fire tornado; your hits ignite, slow, and deal extra damage for 10 seconds.",
			"Cooldown: 45 seconds. Right-click to activate."
	}, "sharpness", 5, "looting", 3, "fire_aspect", 2, "sweeping_edge", 3, "knockback", 2, "unbreaking", 3, "mending", 1);
	public static final class_1792 MOSS_STAINED_EDGE = registerSword("moss_stained_edge", new String[]{
			"An old blade reclaimed by the patient forest.",
			"Passive â€” Hits have a 5% chance to inflict Slowness I for 4 seconds.",
			"Sloth Bubble: A grassy shield blocks 30% of incoming hits, reflects 30% of attacks, and slows nearby enemies for 15 seconds.",
			"Cooldown: 60 seconds. Right-click to activate."
	}, "sharpness", 5, "looting", 3, "fire_aspect", 2, "sweeping_edge", 3, "knockback", 2, "unbreaking", 3, "mending", 1);
	public static final class_1792 CROWN_OF_THE_PROUD = register("crown_of_the_proud",
			new class_1792.class_1793().method_63686(class_5321.method_29179(class_7924.field_41197, id("crown_of_the_proud")))
					.method_7895(407)
					.method_57349(net.minecraft.class_9334.field_54196,
							net.minecraft.class_10192.method_64202(class_1304.field_6169).method_64203())
					.method_57349(net.minecraft.class_9334.field_49630, net.minecraft.class_3902.field_17274)
					.method_57349(net.minecraft.class_9334.field_49632, lore(
							"Passive â€” Pride's Will: 30% chance to ignore damage-based abilities from the other Sins weapons.",
							"Lion's Sun: Crouch-right-click while holding to damage nearby enemies' armor by 100 durability.",
							"Cooldown: 1 minute 45 seconds. The wearer is unaffected."
					))
					);
	static {
		ENCHANTMENTS_BY_ITEM.put(CROWN_OF_THE_PROUD,
				new Object[]{"protection", 4, "thorns", 3, "respiration", 3, "aqua_affinity", 1, "unbreaking", 3, "mending", 1});
	}
	private static final class_1792 SUN_BURST_VISUAL = register("sun_burst_visual",
			new class_1792.class_1793().method_63686(class_5321.method_29179(class_7924.field_41197, id("sun_burst_visual"))).method_7889(1));
	private static final class_1792 SUN_EXPLOSION_VISUAL = internalItem("sun_explosion_visual");
	private static final class_1792 FLAME_TORNADO_VISUAL = internalItem("flame_tornado_visual");
	private static final class_1792 GUARDIAN_SHIELD = internalItem("guardian_shield");

	private static final Map<UUID, Long> cooldowns = new HashMap<>();
	private static final Map<UUID, Long> mawEnds = new HashMap<>();
	private static final Map<UUID, Long> mawNextPulse = new HashMap<>();
	private static final Map<UUID, Long> wrathEnds = new HashMap<>();
	private static final Map<UUID, Long> wrathTornadoNext = new HashMap<>();
	private static final Map<UUID, Long> guardianEnds = new HashMap<>();
	private static final Map<UUID, Long> guardianPulseNext = new HashMap<>();
	private static final Map<UUID, Long> cooldownHudUpdates = new HashMap<>();
	private static final Map<UUID, class_8122> guardianShields = new HashMap<>();
	private static final Map<UUID, class_8122> sunDisplays = new HashMap<>();
	private static final Map<UUID, Long> sunDisplayEnds = new HashMap<>();
	private static final Map<UUID, class_8122> wrathDisplays = new HashMap<>();
	private static final Map<class_8122, Long> burstDisplays = new HashMap<>();
	private static final Map<UUID, Long> hoardBuffEnds = new HashMap<>();
	private static final Set<UUID> reflecting = new HashSet<>();
	private static final Map<UUID, UseRecord> activeConsumptions = new HashMap<>();
	private record UseRecord(class_1792 item, int count, class_1268 hand) {}

	private static class_2960 id(String path) { return class_2960.method_60655(MOD_ID, path); }
	private static class_1792 internalItem(String path) {
		return register(path, new class_1792.class_1793().method_63686(class_5321.method_29179(class_7924.field_41197, id(path))).method_7889(1));
	}
	private static class_1792 registerSword(String path, String[] description) {
		class_2960 key = id(path);
		return register(path, new class_1792.class_1793().method_63686(class_5321.method_29179(class_7924.field_41197, key))
				.method_66333(class_9886.field_52590, 3.0F, -2.4F).method_7889(1)
				.method_57349(net.minecraft.class_9334.field_49632, lore(description)));
	}
	private static class_1792 registerSword(String path, String[] description, Object... enchantmentPairs) {
		class_1792 item = registerSword(path, description);
		ENCHANTMENTS_BY_ITEM.put(item, enchantmentPairs);
		return item;
	}
	private static class_9290 lore(String... lines) {
		return new class_9290(java.util.Arrays.stream(lines).<class_2561>map(class_2561::method_43470).toList());
	}
	private static class_1792 register(String path, class_1792.class_1793 properties) {
		return class_7923.field_41178.method_17966(id(path)).orElseGet(() ->
			net.minecraft.class_2378.method_10230(class_7923.field_41178, id(path), new class_1792(properties)));
	}
	private static boolean holding(class_1657 p, class_1792 i) { return p.method_6047().method_31574(i) || p.method_6079().method_31574(i); }
	private static boolean ready(class_1657 player, class_1792 item, long now) {
		return cooldowns.getOrDefault(key(player, item), 0L) <= now;
	}
	private static UUID key(class_1657 player, class_1792 item) { return UUID.nameUUIDFromBytes((player.method_5667() + ":" + class_7923.field_41178.method_10221(item)).getBytes()); }
	private static void cooldown(class_1657 player, class_1792 item, long now, int seconds) { cooldowns.put(key(player, item), now + seconds * 20L); }
	private static void message(class_1657 p, String text) { p.method_7353(class_2561.method_43470(text), true); }
	private static long now(class_1657 p) { return p.method_73183().method_75260(); }
	private static boolean enemy(class_1309 e, class_1657 p) { return e != p && e.method_5805() && !(e instanceof class_1657 other && p.method_5722(other)); }

	@Override public void onInitialize() {
		ItemGroupEvents.modifyEntriesEvent(net.minecraft.class_7706.field_40202).register(entries -> {
			entries.method_45421(ENDLESS_MAW);
			entries.method_45421(HOARD_EATER);
			entries.method_45421(SIRENS_KISS);
			entries.method_45421(WRATH_SWORD);
			entries.method_45421(MOSS_STAINED_EDGE);
		});
		ItemGroupEvents.modifyEntriesEvent(net.minecraft.class_7706.field_41062)
				.register(entries -> entries.method_45421(CROWN_OF_THE_PROUD));
		AttackEntityCallback.EVENT.register((player, level, hand, target, hit) -> {
			if (level.method_8608() || !(target instanceof class_1309 victim)) return class_1269.field_5811;
			if (holding(player, SIRENS_KISS) && level.field_9229.method_43057() < 0.05F) {
				victim.method_6092(new class_1293(class_1294.field_5911, 400, 0));
				((class_3218) level).method_65096(class_2398.field_11201, victim.method_23317(), victim.method_23318() + victim.method_17682() * 0.65, victim.method_23321(), 6, 0.35, 0.3, 0.35, 0.02);
				((class_3218) level).method_65096(class_2398.field_11249, victim.method_23317(), victim.method_23318() + victim.method_17682() * 0.55, victim.method_23321(), 10, 0.3, 0.3, 0.3, 0.05);
			}
			if (holding(player, MOSS_STAINED_EDGE) && level.field_9229.method_43057() < 0.05F) {
				victim.method_6092(new class_1293(class_1294.field_5909, 80, 0));
				((class_3218) level).method_65096(class_2398.field_17741, victim.method_23317(), victim.method_23318() + 0.6, victim.method_23321(), 12, 0.35, 0.5, 0.35, 0.02);
			}
			if (holding(player, WRATH_SWORD) && wrathEnds.getOrDefault(player.method_5667(), 0L) > now(player)) {
				victim.method_5639(10.0F);
				victim.method_64419(player.method_48923().method_48802(player), 2.0F);
				victim.method_6092(new class_1293(class_1294.field_5909, 100, 0));
				((class_3218) level).method_65096(class_2398.field_11240, victim.method_23317(), victim.method_23318() + 0.8, victim.method_23321(), 18, 0.35, 0.5, 0.35, 0.04);
				((class_3218) level).method_65096(class_2398.field_11239, victim.method_23317(), victim.method_23318() + 0.8, victim.method_23321(), 5, 0.25, 0.45, 0.25, 0.02);
			}
			return class_1269.field_5811;
		});

		UseItemCallback.EVENT.register((player, level, hand) -> {
			class_1799 stack = player.method_5998(hand);
			if (level.method_8608()) return class_1269.field_5811;
			if (holding(player, HOARD_EATER) && (stack.method_31574(class_1802.field_8463) || stack.method_31574(class_1802.field_8367))
					&& level.field_9229.method_43057() < 0.20F) {
				message(player, "The Hoard-Eater rejects the golden apple.");
				return class_1269.field_5814;
			}
			if (hand != class_1268.field_5808 && hand != class_1268.field_5810) return class_1269.field_5811;
			if (stack.method_31574(CROWN_OF_THE_PROUD) && !player.method_18276()) return class_1269.field_5811;
			long time = now(player);
			if (stack.method_31574(ENDLESS_MAW)) {
				if (!ready(player, ENDLESS_MAW, time)) return class_1269.field_5814;
				cooldown(player, ENDLESS_MAW, time, 45);
				mawEnds.put(player.method_5667(), time + 45 * 20L);
				mawNextPulse.put(player.method_5667(), time);
				((class_3218) level).method_65096(class_2398.field_11214, player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 28, 0.5, 0.65, 0.5, 0.35);
				((class_3218) level).method_65096(class_2398.field_23114, player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 12, 0.4, 0.6, 0.4, 0.08);
				level.method_8396(null, player.method_24515(), net.minecraft.class_3417.field_15042, net.minecraft.class_3419.field_15248, 1.2F, 0.55F);
				message(player, "The Endless Maw begins to feed.");
				return class_1269.field_5812;
			}
			if (stack.method_31574(HOARD_EATER)) {
				if (!ready(player, HOARD_EATER, time)) return class_1269.field_5814;
				cooldown(player, HOARD_EATER, time, 30);
				hoardBuffEnds.put(player.method_5667(), time + 30 * 20L);
				((class_3218) level).method_65096(class_2398.field_29642, player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 24, 0.45, 0.6, 0.45, 0.1);
				((class_3218) level).method_65096(class_2398.field_11215, player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 30, 0.45, 0.65, 0.45, 0.8);
				level.method_8396(null, player.method_24515(), net.minecraft.class_3417.field_26980, net.minecraft.class_3419.field_15248, 1.1F, 1.4F);
				message(player, "Hoard-Eater empowers your next golden apple for 30 seconds.");
				return class_1269.field_5812;
			}
			if (stack.method_31574(SIRENS_KISS)) {
				if (!ready(player, SIRENS_KISS, time)) return class_1269.field_5814;
				cooldown(player, SIRENS_KISS, time, 60);
				sirenBurst(player);
				return class_1269.field_5812;
			}
			if (stack.method_31574(WRATH_SWORD)) {
				if (!ready(player, WRATH_SWORD, time)) return class_1269.field_5814;
				cooldown(player, WRATH_SWORD, time, 45);
				wrathEnds.put(player.method_5667(), time + 10 * 20L);
				((class_3218) level).method_65096(class_2398.field_11240, player.method_23317(), player.method_23318() + 0.9, player.method_23321(), 36, 0.55, 0.7, 0.55, 0.08);
				((class_3218) level).method_65096(class_2398.field_11239, player.method_23317(), player.method_23318() + 0.9, player.method_23321(), 8, 0.4, 0.55, 0.4, 0.03);
				level.method_8396(null, player.method_24515(), net.minecraft.class_3417.field_14970, net.minecraft.class_3419.field_15248, 1.0F, 0.7F);
				message(player, "Wrath Flame tornado erupts.");
				return class_1269.field_5812;
			}
			if (stack.method_31574(MOSS_STAINED_EDGE)) {
				if (!ready(player, MOSS_STAINED_EDGE, time)) return class_1269.field_5814;
				cooldown(player, MOSS_STAINED_EDGE, time, 60);
				guardianEnds.put(player.method_5667(), time + 15 * 20L);
				summonGuardianShield((class_3222) player);
				((class_3218) level).method_65096(class_2398.field_17741, player.method_23317(), player.method_23318() + 0.8, player.method_23321(), 28, 0.6, 0.75, 0.6, 0.04);
				((class_3218) level).method_65096(class_2398.field_11211, player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 14, 0.5, 0.7, 0.5, 0.03);
				level.method_8396(null, player.method_24515(), net.minecraft.class_3417.field_28620, net.minecraft.class_3419.field_15248, 1.0F, 0.7F);
				message(player, "Sloth Bubble protects you for 15 seconds.");
				return class_1269.field_5812;
			}
			if (stack.method_31574(CROWN_OF_THE_PROUD)) {
				if (!ready(player, CROWN_OF_THE_PROUD, time)) return class_1269.field_5814;
				cooldown(player, CROWN_OF_THE_PROUD, time, 105);
				sunBurst((class_3218) level, player);
				for (class_1309 entity : level.method_8390(class_1309.class, player.method_5829().method_1014(30), e -> enemy(e, player))) {
					for (class_1304 slot : new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166}) {
						class_1799 armor = entity.method_6118(slot);
						if (armor.method_7963()) armor.method_7974(Math.min(armor.method_7936(), armor.method_7919() + 100));
					}
				}
				level.method_8396(null, player.method_24515(), net.minecraft.class_3417.field_14703,
						net.minecraft.class_3419.field_15248, 1.4F, 0.7F);
				level.method_8396(null, player.method_24515(), net.minecraft.class_3417.field_19167, net.minecraft.class_3419.field_15248, 0.8F, 1.5F);
				message(player, "Lion's Sun erupts in a 30-block radius.");
				return class_1269.field_5812;
			}
			return class_1269.field_5811;
		});

		ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
			if (!(entity instanceof class_1657 holder) || holder.method_73183().method_8608()) return true;
			long time = now(holder);
			if (guardianEnds.getOrDefault(holder.method_5667(), 0L) > time && holder.method_59922().method_43057() < 0.30F) {
				class_3218 level = (class_3218) holder.method_73183();
				level.method_65096(class_2398.field_17741, holder.method_23317(), holder.method_23318() + 1.0, holder.method_23321(), 24, 0.65, 0.75, 0.65, 0.03);
				level.method_8396(null, holder.method_24515(), net.minecraft.class_3417.field_15150.comp_349(), net.minecraft.class_3419.field_15248, 0.8F, 0.75F);
				return false;
			}
			if (!reflecting.contains(holder.method_5667()) && guardianEnds.getOrDefault(holder.method_5667(), 0L) > time && source.method_5529() instanceof class_1309 attacker) {
				reflecting.add(attacker.method_5667());
				try { attacker.method_64419(holder.method_48923().method_48831(), amount * 0.30F); }
				finally { reflecting.remove(attacker.method_5667()); }
			}
			if (holder.method_6118(class_1304.field_6169).method_31574(CROWN_OF_THE_PROUD) && source.method_5529() instanceof class_1657 attacker
					&& isAbilitySword(attacker.method_6047()) && holder.method_59922().method_43057() < 0.30F) return false;
			return true;
		});

		ServerTickEvents.END_SERVER_TICK.register(SinsSmp::tick);
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
			guardianShields.values().forEach(class_8122::method_31472);
			sunDisplays.values().forEach(class_8122::method_31472);
			wrathDisplays.values().forEach(class_8122::method_31472);
			burstDisplays.keySet().forEach(class_8122::method_31472);
			guardianShields.clear();
			guardianEnds.clear();
			guardianPulseNext.clear();
			wrathTornadoNext.clear();
			cooldownHudUpdates.clear();
			sunDisplays.clear();
			sunDisplayEnds.clear();
			wrathDisplays.clear();
			burstDisplays.clear();
		});
	}

	private static boolean isAbilitySword(class_1799 stack) {
		return stack.method_31574(ENDLESS_MAW) || stack.method_31574(HOARD_EATER) || stack.method_31574(SIRENS_KISS) || stack.method_31574(WRATH_SWORD) || stack.method_31574(MOSS_STAINED_EDGE);
	}
	private static void sunBurst(class_3218 level, class_1657 player) {
		UUID ownerId = player.method_5667();
		class_8122 previous = sunDisplays.remove(ownerId);
		if (previous != null) previous.method_31472();
		double x = player.method_23317();
		double y = player.method_23318() + 10.0;
		double z = player.method_23321();
		class_8122 sun = class_1299.field_42456.method_5883(level, class_3730.field_16461);
		if (sun != null) {
			sun.method_5814(x, y, z);
			sun.method_48897(new class_1799(SUN_BURST_VISUAL));
			sun.method_48896(net.minecraft.class_811.field_4319);
			sun.method_48849(new net.minecraft.class_4590(new org.joml.Vector3f(), new org.joml.Quaternionf(), new org.joml.Vector3f(2.0F), new org.joml.Quaternionf()));
			sun.method_5875(true);
			sun.method_5684(true);
			level.method_8649(sun);
			sunDisplays.put(ownerId, sun);
			sunDisplayEnds.put(ownerId, level.method_75260() + 36L);
		}
		class_8122 burst = class_1299.field_42456.method_5883(level, class_3730.field_16461);
		if (burst != null) {
			burst.method_5814(x, y, z);
			burst.method_48897(new class_1799(SUN_EXPLOSION_VISUAL));
			burst.method_48896(net.minecraft.class_811.field_4319);
			burst.method_48849(new net.minecraft.class_4590(new org.joml.Vector3f(), new org.joml.Quaternionf(), new org.joml.Vector3f(3.2F), new org.joml.Quaternionf()));
			burst.method_5875(true);
			burst.method_5684(true);
			level.method_8649(burst);
			burstDisplays.put(burst, level.method_75260() + 12L);
		}
		// A brief white flash at the core, followed by a spherical corona expanding from it.
		level.method_65096(class_9381.method_58256(class_2398.field_17909, 0xFFFFFF), x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
		level.method_65096(class_2398.field_11236, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
		level.method_65096(class_2398.field_11207, x, y, z, 64, 0.45, 0.45, 0.45, 0.12);
		level.method_65096(class_2398.field_11248, x, y, z, 40, 0.55, 0.55, 0.55, 0.18);
		level.method_65096(class_2398.field_11240, x, y, z, 70, 0.8, 0.8, 0.8, 0.16);
		level.method_65096(class_2398.field_11239, x, y, z, 18, 0.65, 0.65, 0.65, 0.08);
		level.method_65096(class_2398.field_11237, x, y, z, 30, 0.9, 0.9, 0.9, 0.055);
		for (int ray = 0; ray < 64; ray++) {
			double vertical = 1.0 - 2.0 * (ray + 0.5) / 64.0;
			double horizontal = Math.sqrt(1.0 - vertical * vertical);
			double angle = ray * 2.399963229728653;
			for (int step = 1; step <= 7; step++) {
				double radius = step * 0.48;
				double px = x + Math.cos(angle) * horizontal * radius;
				double py = y + vertical * radius;
				double pz = z + Math.sin(angle) * horizontal * radius;
				level.method_65096(step % 2 == 0 ? class_2398.field_11207 : class_2398.field_11248,
						px, py, pz, 1, 0.04, 0.04, 0.04, 0.055);
			}
		}
		level.method_8396(null, player.method_24515(), net.minecraft.class_3417.field_14917,
				net.minecraft.class_3419.field_15248, 1.4F, 0.65F);
	}
	private static void sirenBurst(class_1657 p) {
		class_1937 level = p.method_73183();
		class_243 start = p.method_33571();
		class_243 dir = p.method_5720();
		double groundY = p.method_23318() + 0.1;
		((class_3218) level).method_65096(class_2398.field_11236, p.method_23317(), groundY, p.method_23321(), 1, 0.1, 0.0, 0.1, 0.0);
		((class_3218) level).method_65096(class_2398.field_11204, p.method_23317(), groundY, p.method_23321(), 48, 1.8, 0.12, 1.8, 0.16);
		((class_3218) level).method_65096(class_2398.field_11205, p.method_23317(), groundY + 0.15, p.method_23321(), 40, 1.6, 0.08, 1.6, 0.18);
		level.method_8396(null, p.method_24515(), net.minecraft.class_3417.field_15152.comp_349(),
				net.minecraft.class_3419.field_15248, 1.0F, 0.8F);
		level.method_8396(null, p.method_24515(), net.minecraft.class_3417.field_15203,
				net.minecraft.class_3419.field_15248, 0.9F, 1.3F);
		for (int ray = 0; ray < 4; ray++) {
			class_243 offset = new class_243((level.field_9229.method_43058() - .5) * .35, (level.field_9229.method_43058() - .5) * .25, 0);
			class_243 velocity = dir.method_1019(offset).method_1029();
			class_243 side = new class_243(-velocity.field_1350, 0.0, velocity.field_1352);
			if (side.method_1027() < 0.0001) side = new class_243(1.0, 0.0, 0.0);
			else side = side.method_1029();
			class_243 vertical = new class_243(0.0, 1.0, 0.0);
			for (int step = 1; step <= 20; step++) {
				class_243 point = start.method_1019(velocity.method_1021(step));
				for (int width = -1; width <= 1; width++) {
					for (int height = -1; height <= 1; height++) {
						class_243 heart = point.method_1019(side.method_1021(width * 0.24)).method_1019(vertical.method_1021(height * 0.24));
						((class_3218) level).method_65096(class_2398.field_11201,
								heart.field_1352, heart.field_1351, heart.field_1350, 1, .035, .035, .035, 0.005);
					}
				}
				class_1309 victim = level.method_8390(class_1309.class, new class_238(point, point).method_1014(.8), e -> enemy(e, p)).stream().findFirst().orElse(null);
				if (victim != null) {
					switch (level.field_9229.method_43048(4)) {
						case 0 -> victim.method_6092(new class_1293(class_1294.field_5920, 300, 0));
						case 1 -> victim.method_6092(new class_1293(class_1294.field_5899, 400, 0));
						case 2 -> victim.method_6092(new class_1293(class_1294.field_5903, 400, 0));
						default -> victim.method_64419(p.method_48923().method_48802(p), 8.0F);
					}
					break;
				}
			}
		}
		message(p, "Lust's Lament unleashed.");
	}
	private static void showAbilityCooldown(class_3222 player, long time) {
		class_1799 held = player.method_6047();
		if (!isAbilitySword(held) && !held.method_31574(CROWN_OF_THE_PROUD)) held = player.method_6079();
		if (!isAbilitySword(held) && !held.method_31574(CROWN_OF_THE_PROUD)) {
			cooldownHudUpdates.remove(player.method_5667());
			return;
		}
		class_1792 ability = held.method_7909();
		long previousUpdate = cooldownHudUpdates.getOrDefault(player.method_5667(), Long.MIN_VALUE);
		if (previousUpdate != Long.MIN_VALUE && previousUpdate / 20L == time / 20L) return;
		cooldownHudUpdates.put(player.method_5667(), time);
		long remaining = cooldowns.getOrDefault(key(player, ability), 0L) - time;
		String name = ability == ENDLESS_MAW ? "Endless Hunger" : ability == HOARD_EATER ? "Feast of Gold"
				: ability == SIRENS_KISS ? "Lust's Lament" : ability == WRATH_SWORD ? "Wrath Flame"
				: ability == MOSS_STAINED_EDGE ? "Sloth Bubble" : "Lion's Sun";
		String instruction = ability == CROWN_OF_THE_PROUD ? "  •  Sneak + right-click" : "  •  Right-click";
		class_2561 status = remaining <= 0
				? class_2561.method_43470(name + "  •  READY" + instruction).method_27692(net.minecraft.class_124.field_1060)
				: class_2561.method_43470(name + "  •  Cooldown: " + ((remaining + 19L) / 20L) + "s").method_27692(net.minecraft.class_124.field_1061);
		player.method_7353(status, true);
	}
	private static void tick(MinecraftServer server) {
		updateGuardianShields(server);
		updateSunDisplays(server);
		for (class_3222 player : server.method_3760().method_14571()) {
			long time = player.method_51469().method_75260();
			showAbilityCooldown(player, time);
			removeExpiredHoardBuff(player, time);
			trackConsumption(player);
			for (int slot = 0; slot < player.method_31548().method_5439(); slot++)
				applyDefaultEnchantments(player, player.method_31548().method_5438(slot));
			for (class_1304 slot : new class_1304[]{class_1304.field_6171, class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166})
				applyDefaultEnchantments(player, player.method_6118(slot));
			if (holding(player, WRATH_SWORD) && player.method_6047().method_31574(WRATH_SWORD)) player.method_6092(new class_1293(class_1294.field_5910, 40, 1, true, false));
			if (wrathEnds.getOrDefault(player.method_5667(), 0L) > time && time >= wrathTornadoNext.getOrDefault(player.method_5667(), 0L)) {
				flameTornado((class_3218) player.method_51469(), player);
				wrathTornadoNext.put(player.method_5667(), time + 10L);
			} else if (wrathEnds.getOrDefault(player.method_5667(), 0L) <= time) {
				wrathEnds.remove(player.method_5667());
				wrathTornadoNext.remove(player.method_5667());
			}
			updateWrathDisplay((class_3218) player.method_51469(), player, time);
			if (guardianEnds.getOrDefault(player.method_5667(), 0L) > time) {
				if (time % 5L == 0L) grassyShield((class_3218) player.method_51469(), player);
				if (time >= guardianPulseNext.getOrDefault(player.method_5667(), 0L)) {
					slothPulse(player);
					guardianPulseNext.put(player.method_5667(), time + 60L);
				}
			} else {
				guardianPulseNext.remove(player.method_5667());
			}
			long end = mawEnds.getOrDefault(player.method_5667(), 0L);
			if (end > time && time >= mawNextPulse.getOrDefault(player.method_5667(), Long.MAX_VALUE)) {
				for (class_1657 target : player.method_51469().method_8390(class_1657.class, player.method_5829().method_1014(7), p -> p != player && !player.method_5722(p))) {
					var food = target.method_7344();
					food.method_7581(food.method_7589() * 0.90F);
					class_3218 targetLevel = (class_3218) target.method_73183();
					targetLevel.method_65096(class_2398.field_11214, target.method_23317(), target.method_23318() + 0.8, target.method_23321(), 16, 0.35, 0.5, 0.35, 0.22);
					targetLevel.method_65096(class_2398.field_23114, target.method_23317(), target.method_23318() + 0.8, target.method_23321(), 5, 0.25, 0.4, 0.25, 0.04);
				}
				mawNextPulse.put(player.method_5667(), time + 10 * 20L);
			}
			if (end != 0 && end <= time) mawEnds.remove(player.method_5667());
		}
	}
	private static void updateSunDisplays(MinecraftServer server) {
		long time = server.method_30002().method_75260();
		var iterator = sunDisplays.entrySet().iterator();
		while (iterator.hasNext()) {
			var entry = iterator.next();
			if (sunDisplayEnds.getOrDefault(entry.getKey(), 0L) <= time || !entry.getValue().method_5805()) {
				entry.getValue().method_31472();
				sunDisplayEnds.remove(entry.getKey());
				iterator.remove();
			}
		}
		var burstIterator = burstDisplays.entrySet().iterator();
		while (burstIterator.hasNext()) {
			var entry = burstIterator.next();
			class_8122 display = entry.getKey();
			if (entry.getValue() <= time || !display.method_5805()) {
				display.method_31472();
				burstIterator.remove();
			} else {
				display.method_36456((time * 8.0F) % 360.0F);
			}
		}
	}
	private static void updateWrathDisplay(class_3218 level, class_1657 player, long time) {
		UUID id = player.method_5667();
		if (wrathEnds.getOrDefault(id, 0L) <= time) {
			class_8122 old = wrathDisplays.remove(id);
			if (old != null) old.method_31472();
			return;
		}
		class_8122 tornado = wrathDisplays.get(id);
		if (tornado == null || !tornado.method_5805()) {
			tornado = class_1299.field_42456.method_5883(level, class_3730.field_16461);
			if (tornado == null) return;
			tornado.method_48897(new class_1799(FLAME_TORNADO_VISUAL));
			tornado.method_48896(net.minecraft.class_811.field_4319);
			tornado.method_48849(new net.minecraft.class_4590(new org.joml.Vector3f(), new org.joml.Quaternionf(), new org.joml.Vector3f(2.6F), new org.joml.Quaternionf()));
			tornado.method_5875(true);
			tornado.method_5684(true);
			level.method_8649(tornado);
			wrathDisplays.put(id, tornado);
		}
		tornado.method_5814(player.method_23317(), player.method_23318() + 1.0, player.method_23321());
		tornado.method_36456((time * 9.0F) % 360.0F);
	}
	private static void flameTornado(class_3218 level, class_1657 player) {
		double phase = level.method_75260() * 0.32;
		for (int ring = 0; ring < 8; ring++) {
			double y = player.method_23318() + ring * 0.48 + 0.15;
			double radius = 0.42 + ring * 0.20;
			for (int point = 0; point < 9; point++) {
				double angle = phase + Math.PI * 2.0 * point / 9.0 + ring * 0.62;
				double x = player.method_23317() + Math.cos(angle) * radius;
				double z = player.method_23321() + Math.sin(angle) * radius;
				level.method_65096((ring + point) % 4 == 0 ? class_2398.field_11251 : class_2398.field_11240,
						x, y, z, 1, 0.025, 0.06, 0.025, 0.015);
				if ((ring + point) % 3 == 0) level.method_65096(class_2398.field_11239, x, y, z, 1, 0.025, 0.04, 0.025, 0.01);
				if (point % 3 == 0) level.method_65096(class_2398.field_11237, x, y + 0.12, z, 1, 0.04, 0.08, 0.04, 0.01);
			}
		}
	}
	private static void grassyShield(class_3218 level, class_1657 player) {
		for (int height = 0; height < 3; height++) {
			double y = player.method_23318() + 0.35 + height * 0.65;
			for (int point = 0; point < 12; point++) {
				double angle = Math.PI * 2.0 * point / 12.0 + level.method_75260() * 0.035;
				double x = player.method_23317() + Math.cos(angle) * 1.25;
				double z = player.method_23321() + Math.sin(angle) * 1.25;
				level.method_65096(height == 1 ? class_2398.field_11211 : class_2398.field_17741,
						x, y, z, 1, 0.035, 0.08, 0.035, 0.01);
			}
		}
	}
	private static void slothPulse(class_1657 owner) {
		class_1937 level = owner.method_73183();
		for (class_1309 target : level.method_8390(class_1309.class, owner.method_5829().method_1014(5.0), e -> enemy(e, owner))) {
			target.method_6092(new class_1293(class_1294.field_5909, 60, 0));
			class_243 push = target.method_73189().method_1020(owner.method_73189());
			if (push.method_1027() > 0.0001) target.method_5762(push.method_1029().field_1352 * 0.65, 0.22, push.method_1029().field_1350 * 0.65);
			((class_3218) level).method_65096(class_2398.field_17741, target.method_23317(), target.method_23318() + 0.8, target.method_23321(), 12, 0.35, 0.5, 0.35, 0.02);
		}
		((class_3218) level).method_65096(class_2398.field_11211, owner.method_23317(), owner.method_23318() + 0.9, owner.method_23321(), 20, 1.8, 0.7, 1.8, 0.04);
		level.method_8396(null, owner.method_24515(), net.minecraft.class_3417.field_28620, net.minecraft.class_3419.field_15248, 0.6F, 0.8F);
	}
	private static void summonGuardianShield(class_3222 owner) {
		class_8122 previous = guardianShields.remove(owner.method_5667());
		if (previous != null) previous.method_31472();
		class_243 position = shieldPosition(owner);
		class_3218 level = (class_3218) owner.method_51469();
		class_8122 shield = class_1299.field_42456.method_5883(level, class_3730.field_16461);
		if (shield == null) return;
		shield.method_48897(new class_1799(GUARDIAN_SHIELD));
		shield.method_48896(net.minecraft.class_811.field_4319);
		shield.method_5814(position.field_1352, position.field_1351, position.field_1350);
		shield.method_36456(owner.method_36454() + 180.0F);
		shield.method_5875(true);
		shield.method_5684(true);
		level.method_8649(shield);
		guardianShields.put(owner.method_5667(), shield);
	}
	private static class_243 shieldPosition(class_3222 owner) {
		double angle = owner.method_36454() * (Math.PI / 180.0);
		return new class_243(owner.method_23317() - Math.sin(angle) * 1.0, owner.method_23318() + 0.15, owner.method_23321() + Math.cos(angle) * 1.0);
	}
	private static void updateGuardianShields(MinecraftServer server) {
		var iterator = guardianShields.entrySet().iterator();
		while (iterator.hasNext()) {
			var entry = iterator.next();
			class_3222 owner = server.method_3760().method_14602(entry.getKey());
			class_8122 shield = entry.getValue();
			if (owner == null || guardianEnds.getOrDefault(entry.getKey(), 0L) <= owner.method_51469().method_75260()) {
				shield.method_31472();
				guardianEnds.remove(entry.getKey());
				guardianPulseNext.remove(entry.getKey());
				iterator.remove();
				continue;
			}
			if (shield.method_73183() != owner.method_51469()) {
				shield.method_31472();
				iterator.remove();
				summonGuardianShield(owner);
				continue;
			}
			class_243 position = shieldPosition(owner);
			shield.method_5859(position.field_1352, position.field_1351, position.field_1350);
			shield.method_36456(owner.method_36454() + 180.0F);
		}
	}
	private static void applyDefaultEnchantments(class_3222 player, class_1799 stack) {
		Object[] pairs = ENCHANTMENTS_BY_ITEM.get(stack.method_7909());
		if (pairs == null || !stack.method_58695(net.minecraft.class_9334.field_49633, class_9304.field_49385).method_57543()) return;
		class_2378<class_1887> registry = player.method_51469().method_30349().method_30530(class_7924.field_41265);
		class_9304.class_9305 enchantments = new class_9304.class_9305(class_9304.field_49385);
		for (int i = 0; i < pairs.length; i += 2) {
			class_5321<class_1887> key = class_5321.method_29179(class_7924.field_41265,
					class_2960.method_60656((String) pairs[i]));
			class_6880<class_1887> enchantment = registry.method_46747(key);
			enchantments.method_57547(enchantment, (int) pairs[i + 1]);
		}
		stack.method_57379(net.minecraft.class_9334.field_49633, enchantments.method_57549());
	}
	private static void trackConsumption(class_3222 player) {
		UUID uuid = player.method_5667();
		if (player.method_6115()) {
			class_1799 used = player.method_6030();
			activeConsumptions.put(uuid, new UseRecord(used.method_7909(), used.method_7947(), player.method_6058()));
			return;
		}
		UseRecord record = activeConsumptions.remove(uuid);
		if (record == null || player.method_5998(record.hand()).method_7947() >= record.count()) return;
		class_1799 consumed = new class_1799(record.item());
		var food = consumed.method_58694(net.minecraft.class_9334.field_50075);
		if (food != null) onFoodEaten(player, food);
		if (record.item() == class_1802.field_8463 || record.item() == class_1802.field_8367)
			onGoldenAppleEaten(player);
	}
	private static void removeExpiredHoardBuff(class_1657 player, long time) {
		if (hoardBuffEnds.getOrDefault(player.method_5667(), 0L) <= time) hoardBuffEnds.remove(player.method_5667());
	}
	public static void onFoodEaten(class_1657 player, net.minecraft.class_4174 food) {
		if (!player.method_73183().method_8608() && holding(player, ENDLESS_MAW)) {
			var data = player.method_7344();
			float extraSaturation = food.comp_2491() * food.comp_2492() * 0.8F;
			data.method_7581(Math.min(data.method_7586(), data.method_7589() + extraSaturation));
		}
	}
	public static void onGoldenAppleEaten(class_1657 player) {
		if (player.method_73183().method_8608() || hoardBuffEnds.getOrDefault(player.method_5667(), 0L) <= now(player)) return;
		class_3218 level = (class_3218) player.method_73183();
		level.method_65096(class_2398.field_29642, player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 36, 0.55, 0.8, 0.55, 0.12);
		level.method_65096(class_2398.field_11215, player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 40, 0.55, 0.8, 0.55, 1.0);
		class_1293 regeneration = player.method_6112(class_1294.field_5924);
		if (regeneration != null) player.method_6092(new class_1293(class_1294.field_5924,
				(int) Math.ceil(regeneration.method_5584() * 1.10), regeneration.method_5578(),
				regeneration.method_5591(), regeneration.method_5581(), regeneration.method_5592()));
		hoardBuffEnds.remove(player.method_5667());
	}
}

